# Rink Gallery World

Standalone Three.js + Vite rink gallery using your artwork and GLB model.

## Local

  npm install
  npm run dev

## Build

  npm run build

## Vercel

- Install command: npm install
- Build command: npm run build
- Output directory: dist
